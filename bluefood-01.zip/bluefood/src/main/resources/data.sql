INSERT INTO categoria_restaurante (nome, imagem) VALUES ('Pizza','0001-categoria.png');
INSERT INTO categoria_restaurante (nome, imagem) VALUES ('Sanduíche','0002-categoria.png');
INSERT INTO categoria_restaurante (nome, imagem) VALUES ('Churrasco','0003-categoria.png');
INSERT INTO categoria_restaurante (nome, imagem) VALUES ('Salada','0004-categoria.png');
INSERT INTO categoria_restaurante (nome, imagem) VALUES ('Sobremesa','0005-categoria.png');
INSERT INTO categoria_restaurante (nome, imagem) VALUES ('Japonês','0006-categoria.png');