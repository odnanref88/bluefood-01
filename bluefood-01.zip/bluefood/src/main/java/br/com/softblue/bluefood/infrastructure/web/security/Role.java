package br.com.softblue.bluefood.infrastructure.web.security;

public enum Role {
      
	CLIENTE, RESTAURANTE;
}
