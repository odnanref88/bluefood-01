package br.com.softblue.bluefood.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import br.com.softblue.bluefood.domain.restaurante.CategoriaRestaurante;
import br.com.softblue.bluefood.domain.restaurante.CategoriaRestauranteRepository;

@DataJpaTest
@ActiveProfiles("test")
public class CategoriaRestauranteRepositoryTest {
	
	@SuppressWarnings("unused")
	@Autowired
	private CategoriaRestauranteRepository categoriaRestautanteRepository;

    
	@Test
	public void testInsertAndDelete() throws Exception {
		
		assertThat(categoriaRestautanteRepository).isNotNull();
		
		CategoriaRestaurante cr = new CategoriaRestaurante();
		cr.setNome("Chinesa");
		cr.setImagem("chinesa.png");
		categoriaRestautanteRepository.saveAndFlush(cr);
		
		assertThat(cr.getId()).isNotNull();
		
		CategoriaRestaurante cr2 = categoriaRestautanteRepository.findById(cr.getId()).orElseThrow(NoSuchElementException::new);
		assertThat(cr.getNome()).isEqualTo(cr2.getNome());
		
		assertThat(categoriaRestautanteRepository.findAll()).hasSize(7);
		
		categoriaRestautanteRepository.delete(cr);
		
		assertThat(categoriaRestautanteRepository.findAll()).hasSize(6);
	}
}
